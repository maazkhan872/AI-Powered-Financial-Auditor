import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import joblib
from datetime import datetime
from sklearn.preprocessing import LabelEncoder

# Load custom CSS
with open("templates/custom.css") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# Page config
st.set_page_config(page_title="SmartLedger - AI Financial Audit", layout="wide")

# Header section
col1, col2 = st.columns([1, 8])
with col1:
    try:
        st.image("static/logo.png", width=80)
    except:
        st.warning(" Logo not found")

with col2:
    st.markdown("""
    <div class="header-card">
        <h1>SmartLedger</h1>
        <p style='color:#ccc;'>AI-powered financial audit dashboard</p>
    </div>
    """, unsafe_allow_html=True)

# Sidebar upload
st.sidebar.header("📁 Upload Financial Dataset")
uploaded_file = st.sidebar.file_uploader("Upload CSV", type=["csv"])

if uploaded_file:
    df = pd.read_csv(uploaded_file)

    #  Dataset Preview heading
    st.markdown("""
    <div style='display: flex; align-items: center; gap: 10px;'>
        🧾 <strong style='font-size: 20px;'>Dataset Preview</strong>
    </div>
    """, unsafe_allow_html=True)
    st.dataframe(df.head())

    # Clean date column
    if 'Date' in df.columns:
        df['Date'] = pd.to_datetime(df['Date'], errors='coerce')

    # Report and Graphs heading
    st.markdown("""
    <div style='display: flex; align-items: center; gap: 10px; margin-top: 30px;'>
        📊 <strong style='font-size: 20px;'>Report and Data Behavior Analysis</strong>
    </div>
    """, unsafe_allow_html=True)

    colA, colB = st.columns(2)
    with colA:
        if 'Amount' in df.columns and 'Date' in df.columns:
            fig1 = px.line(df.sort_values('Date'), x='Date', y='Amount', title='Amount Trend Over Time')
            st.plotly_chart(fig1, use_container_width=True)

    with colB:
        if 'Flag' in df.columns:
            fig2 = px.histogram(df, x='Flag', color='Flag', title='Flag Distribution')
            st.plotly_chart(fig2, use_container_width=True)

    if 'Record_Type' in df.columns and 'Amount' in df.columns:
        fig3 = px.box(df, x='Record_Type', y='Amount', title='Amount Distribution by Record Type', color='Record_Type')
        st.plotly_chart(fig3, use_container_width=True)

    if 'Parent_Account' in df.columns:
        #  Parent Account heading
        st.markdown("""
        <div style='display: flex; align-items: center; gap: 10px; margin-top: 30px;'>
            💼 <strong style='font-size: 20px;'>Total Amount by Parent Account</strong>
        </div>
        """, unsafe_allow_html=True)
        agg_df = df.groupby('Parent_Account')["Amount"].sum().reset_index().sort_values("Amount", ascending=False)
        fig4 = px.bar(agg_df, x='Parent_Account', y='Amount', title='Total Amount by Parent Account')
        st.plotly_chart(fig4, use_container_width=True)

    #  Prediction Section
    if 'Flag' in df.columns:
        st.markdown("""
        <div style='display: flex; align-items: center; gap: 10px; margin-top: 30px;'>
             <strong style='font-size: 20px;'>AI Model Prediction</strong>
        </div>
        """, unsafe_allow_html=True)
        model = joblib.load("model.pkl")
        le = LabelEncoder()
        df['Flag_encoded'] = le.fit_transform(df['Flag'])

        features = df.select_dtypes(include='number').drop(columns=['Flag_encoded'], errors='ignore')
        if not features.empty:
            preds = model.predict(features)
            decoded_preds = le.inverse_transform(preds)
            df['Predicted_Flag'] = decoded_preds

            if 'Account_ID' in df.columns:
                st.dataframe(df[['Account_ID', 'Predicted_Flag']])
            else:
                st.dataframe(df[['Predicted_Flag']])

            # Export report
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = f"audit_report_{timestamp}.csv"
            df.to_csv(output_file, index=False)
            with open(output_file, "rb") as f:
                st.download_button("📥 Download Audit Report", f, file_name=output_file, mime="text/csv")

else:
    st.info("👈 Upload a financial CSV file from the sidebar to get started.")
