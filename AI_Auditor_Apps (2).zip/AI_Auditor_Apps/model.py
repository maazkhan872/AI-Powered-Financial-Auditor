# Required libraries
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import pandas as pd
import joblib

# NEW: Import for XGBoost
from xgboost import XGBClassifier
import seaborn as sns
import matplotlib.pyplot as plt

# Load your cleaned or balanced dataset using correct path
df_balanced = pd.read_csv("Financial_dataset.csv")

# Encode labels
le = LabelEncoder()
df_balanced['Flag_encoded'] = le.fit_transform(df_balanced['Flag'])

# Features and target
X = df_balanced.select_dtypes(include='number').drop(columns=['Flag_encoded'])
y = df_balanced['Flag_encoded']

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)


# Random Forest Model

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Evaluate
y_pred = model.predict(X_test)
print("Classification Report (Random Forest):\n")
print(classification_report(y_test, y_pred, target_names=le.classes_))

# Save Random Forest model
joblib.dump(model, 'model.pkl')
print(" Model saved successfully as model.pkl")


# XGBoost Model

xgb_model = XGBClassifier(
    objective='multi:softmax',
    num_class=len(le.classes_),
    eval_metric='mlogloss',
    use_label_encoder=False,
    random_state=42
)
xgb_model.fit(X_train, y_train)

# Evaluate
xgb_pred = xgb_model.predict(X_test)
print("Classification Report (XGBoost):")
print(classification_report(y_test, xgb_pred, target_names=le.classes_))

# Confusion Matrix
cm = confusion_matrix(y_test, xgb_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=le.classes_, yticklabels=le.classes_)
plt.title("XGBoost - Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.show()

# Save XGBoost model
joblib.dump(xgb_model, 'xgboost_model.pkl')
print(" Model saved successfully as xgboost_model.pkl")
